# Kid Weather Helper

This folder contains a static weather app with a branded landing page.

## How to use
- Open `landing.html` or double-click `Kid Weather.url`.
- Click **Launch Weather App** to open the weather tool.

## Sharing the app
1. Host this folder on a web server or GitHub Pages.
2. Share the hosted site URL with friends.
3. The landing page includes a copy link button.

## GitHub Pages
If you upload this repository to GitHub and enable Pages from the `main` branch root, your app will be available at:

`https://<your-github-username>.github.io/<repository-name>/landing.html`

Then people can open that URL directly.

## Make it available on phone

To use the app on your phone, host the files somewhere public or on your local network.

- For a public link, upload the folder to GitHub and enable Pages on the repository.
- For local network access, run a simple web server in this folder and open `http://<computer-ip>:8080/landing.html` on your phone.

Example (if Python is installed):

```powershell
cd "c:\Users\ilove\OneDrive\Desktop\Kid weather"
python -m http.server 8080
```

Then open `http://<your-pc-ip>:8080/landing.html` from your phone browser.
