let searchButton;
let geolocateButton;
let themeToggleButton;
let locationInput;
let resultSection;
let errorSection;
let placeNameEl;
let weatherDescEl;
let temperatureEl;
let highLowEl;
let humidityEl;
let windEl;
let conditionEl;
let rainChanceEl;
let feelsLikeEl;
let clothingAdviceEl;

function setText(element, value) {
  if (element) {
    element.textContent = value;
  }
}

function initializeElements() {
  searchButton = document.getElementById('searchButton');
  geolocateButton = document.getElementById('geolocateButton');
  themeToggleButton = document.getElementById('themeToggleButton');
  locationInput = document.getElementById('location');
  resultSection = document.getElementById('result');
  errorSection = document.getElementById('error');
  placeNameEl = document.getElementById('placeName');
  weatherDescEl = document.getElementById('weatherDesc');
  temperatureEl = document.getElementById('temperature');
  highLowEl = document.getElementById('highLow');
  humidityEl = document.getElementById('humidity');
  windEl = document.getElementById('wind');
  conditionEl = document.getElementById('condition');
  rainChanceEl = document.getElementById('rainChance');
  feelsLikeEl = document.getElementById('feelsLike');
  clothingAdviceEl = document.getElementById('clothingAdvice');
}

function attachEventHandlers() {
  if (searchButton) {
    searchButton.addEventListener('click', () => {
      const location = locationInput?.value.trim();
      if (!location) {
        showError('Please enter a city or town name.');
        return;
      }
      fetchWeatherForName(location);
    });
  }

  if (themeToggleButton) {
    themeToggleButton.addEventListener('click', toggleTheme);
  }

  if (geolocateButton) {
    geolocateButton.addEventListener('click', handleGeolocation);
  }
}

function setup() {
  initializeElements();
  attachEventHandlers();
  initializeTheme();
}

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', setup);
} else {
  setup();
}

function handleGeolocation() {
  if (!navigator.geolocation) {
    showError('Geolocation is not supported in your browser.');
    return;
  }

  navigator.geolocation.getCurrentPosition(
    async (position) => {
      const { latitude, longitude } = position.coords;
      await fetchWeather(latitude, longitude, 'Current location');
    },
    () => {
      showError('Unable to retrieve your current location. Please try again or search by city name.');
    }
  );
}

async function fetchWeatherForName(place) {
  showError('');
  const safePlace = encodeURIComponent(place);
  const geocodeUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${safePlace}&count=1&language=en&format=json`;

  try {
    const response = await fetch(geocodeUrl);
    if (!response.ok) throw new Error('Location lookup failed.');
    const data = await response.json();

    if (!data.results || data.results.length === 0) {
      showError('No matching location found. Please try a different city or town.');
      return;
    }

    const location = data.results[0];
    await fetchWeather(location.latitude, location.longitude, `${location.name}, ${location.country}`);
  } catch (error) {
    showError(error.message || 'Unable to load location data right now.');
  }
}

async function fetchWeather(latitude, longitude, placeLabel) {
  showError('');
  const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&hourly=relativehumidity_2m,windspeed_10m,precipitation_probability&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=auto`;

  try {
    const response = await fetch(weatherUrl);
    if (!response.ok) throw new Error('Weather service is unavailable.');
    const data = await response.json();

    if (!data.current_weather) {
      showError('Weather data is not available for this location.');
      return;
    }

    displayWeather(data, placeLabel);
  } catch (error) {
    showError(error.message || 'Unable to load weather data right now.');
  }
}

function displayWeather(data, placeLabel) {
  const weather = data.current_weather;
  const tempC = weather.temperature;
  const tempF = celsiusToFahrenheit(tempC);
  const highC = data.daily?.temperature_2m_max?.[0];
  const lowC = data.daily?.temperature_2m_min?.[0];
  const feelsLikeC = temperatureFeelsLike(tempC, highC, lowC);
  const feelsLikeF = celsiusToFahrenheit(feelsLikeC);
  const condition = weatherCodeToDescription(weather.weathercode);
  const currentIndex = data.hourly?.time?.indexOf(weather.time) ?? -1;
  const humidity = currentIndex >= 0 ? data.hourly.relativehumidity_2m[currentIndex] : null;
  const windspeed = currentIndex >= 0 ? data.hourly.windspeed_10m[currentIndex] : null;
  const rainChance = currentIndex >= 0 ? data.hourly.precipitation_probability[currentIndex] : data.daily?.precipitation_probability_max?.[0] ?? 0;
  const precipitation = data.daily?.precipitation_sum?.[0] ?? 0;

  setText(placeNameEl, placeLabel);
  setText(weatherDescEl, `Right now it is ${condition.toLowerCase()} with a temperature of ${Math.round(tempC)}°C (${Math.round(tempF)}°F), feels like ${Math.round(feelsLikeC)}°C (${Math.round(feelsLikeF)}°F).`);
  setText(temperatureEl, `${Math.round(tempC)}°C / ${Math.round(tempF)}°F`);
  setText(highLowEl, highC != null && lowC != null ? `${Math.round(highC)}°C / ${Math.round(lowC)}°C` : 'N/A');
  setText(humidityEl, humidity != null ? `${Math.round(humidity)}%` : 'N/A');
  setText(windEl, windspeed != null ? `${Math.round(windspeed)} km/h` : 'N/A');
  setText(conditionEl, condition);
  setText(rainChanceEl, `${Math.round(rainChance)}%`);
  setText(feelsLikeEl, `${Math.round(feelsLikeC)}°C / ${Math.round(feelsLikeF)}°F`);
  setText(clothingAdviceEl, buildAdvice(tempC, feelsLikeC, condition, rainChance, precipitation));
  if (resultSection) {
    resultSection.classList.remove('hidden');
  }
}

function celsiusToFahrenheit(celsius) {
  return celsius * 9 / 5 + 32;
}

function temperatureFeelsLike(temp, high, low) {
  if (high == null || low == null) return temp;
  const spread = Math.abs(high - low);
  return temp - Math.min(spread * 0.1, 3);
}

function buildAdvice(temp, feelsLike, condition, rainChance, precipitation) {
  const isRainy = rainChance > 35 || /rain|shower|drizzle/.test(condition.toLowerCase());
  const isSnowy = /snow|sleet|ice/.test(condition.toLowerCase());
  const advice = [];

  const useTemperature = feelsLike != null ? feelsLike : temp;

  if (useTemperature <= 0) {
    advice.push('A heavy winter coat, warm hat, gloves, and sturdy boots');
  } else if (useTemperature <= 8) {
    advice.push('A warm coat, long pants, and a hat');
  } else if (useTemperature <= 15) {
    advice.push('A jacket or sweater with pants');
  } else if (useTemperature <= 20) {
    advice.push('A long-sleeve shirt or light hoodie with pants');
  } else if (useTemperature <= 27) {
    advice.push('A t-shirt or light top with comfortable pants or shorts');
  } else {
    advice.push('A t-shirt, shorts, sun hat, and sunscreen if the sun is out');
  }

  if (isRainy) {
    advice.push('Take a raincoat or umbrella');
  }

  if (isSnowy) {
    advice.push('Snow boots and warm gloves are a good idea');
  }

  if (!isRainy && temp >= 20) {
    advice.push('A water bottle is helpful for staying hydrated');
  }

  return advice.join('. ') + '.';
}

function weatherCodeToDescription(code) {
  const map = {
    0: 'Clear sky',
    1: 'Mainly clear',
    2: 'Partly cloudy',
    3: 'Overcast',
    45: 'Fog',
    48: 'Depositing rime fog',
    51: 'Light drizzle',
    53: 'Moderate drizzle',
    55: 'Dense drizzle',
    56: 'Light freezing drizzle',
    57: 'Dense freezing drizzle',
    61: 'Slight rain',
    63: 'Moderate rain',
    65: 'Heavy rain',
    66: 'Light freezing rain',
    67: 'Heavy freezing rain',
    71: 'Slight snow fall',
    73: 'Moderate snow fall',
    75: 'Heavy snow fall',
    77: 'Snow grains',
    80: 'Slight rain showers',
    81: 'Moderate rain showers',
    82: 'Violent rain showers',
    85: 'Slight snow showers',
    86: 'Heavy snow showers',
    95: 'Thunderstorm',
    96: 'Thunderstorm with slight hail',
    99: 'Thunderstorm with heavy hail'
  };
  return map[code] || 'Unusual weather';
}

function showError(message) {
  if (!errorSection) return;

  if (!message) {
    errorSection.classList.add('hidden');
    errorSection.textContent = '';
    return;
  }

  errorSection.textContent = message;
  errorSection.classList.remove('hidden');
}

function initializeTheme() {
  const storedTheme = localStorage.getItem('kidWeatherTheme') || 'light';
  document.body.classList.toggle('dark-mode', storedTheme === 'dark');
  if (themeToggleButton) {
    themeToggleButton.textContent = storedTheme === 'dark' ? 'Light mode' : 'Dark mode';
  }
}

function toggleTheme() {
  const isDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('kidWeatherTheme', isDark ? 'dark' : 'light');
  if (themeToggleButton) {
    themeToggleButton.textContent = isDark ? 'Light mode' : 'Dark mode';
  }
}
